class TodoITem < ActiveRecord::Base
end
